from django import forms
from .models import Cargos

class CargoForm(forms.ModelForm):
    class Meta:
        model = Cargos
        fields = ['cod_cargo','desc_cargo','inscricao_aberta']