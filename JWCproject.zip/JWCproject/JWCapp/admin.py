# JWC project

from django.contrib import admin

from .models import Cargos
from .models import Inscricoes

admin.site.register(Cargos)
admin.site.register(Inscricoes) 
