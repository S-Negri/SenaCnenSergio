# Projeto JWC

from django.db import models

# Create your models here.

class Cargos(models.Model):
    cod_cargo =  models.CharField(max_length=2, primary_key=True, unique=True)  
    desc_cargo = models.CharField(max_length=35) 
    inscricao_aberta = models.CharField(max_length=1, default='N')

    def __str__(self):
        return (self.cod_cargo + ' - ' + self.desc_cargo + '   -   ' + self.inscricao_aberta)
    
class Inscricoes(models.Model):
    cpf = models.CharField(max_length=11, primary_key=True, unique=True) 
    nome =  models.CharField(max_length=11)
    dt_nasc = models.DateField()
    e_mail = models.EmailField()
    curriculo = models.ImageField()
    insc_codcargo = models.ForeignKey(Cargos, to_field='cod_cargo', on_delete=models.PROTECT)
