from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Cargos

#estáticas

def home(request):
    return HttpResponse("<h1>Bem-vindo à JWC!</h1> <p>essa é a HOME estatica.</p>")

# dinâmicas

def jwcapp(request):
   template = loader.get_template('home.html')
   return HttpResponse(template.render())

def clientes(request):
    template = loader.get_template('clientes.html')
    return HttpResponse(template.render())

def contatos(request):
    template = loader.get_template('contatos.html')
    return HttpResponse(template.render())

def equipe(request):
    template = loader.get_template('equipe.html')
    return HttpResponse(template.render())

def trabalheconosco(request):
    template = loader.get_template('trabalheconosco.html')
    return HttpResponse(template.render())

def inscricao(request):
    template = loader.get_template('inscricao.html')
    return HttpResponse(template.render())

def cargos(request):
    template = loader.get_template('listacargos.html')
    return HttpResponse(template.render())

def frmcargo(request):
    template = loader.get_template('frmcargo.html')
    return HttpResponse(template.render())

## QUERYSETs

def listar_cargos(request): 
    listarcargos = Cargos.objects.all()
    return render(request, 'listacargos.html', {'lista': listarcargos}) 

