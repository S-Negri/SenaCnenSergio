"""
 URL do APP JWC
"""

from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name='home'),
    path('clientes/',views.clientes, name='clientes'),
    path('contatos/',views.contatos, name='contatos'),
    path('equipe/',views.equipe, name='equipe'),
    path('trabalheconosco/',views.trabalheconosco, name='trabalheconosco'),
    path('inscricao/',views.inscricao, name='inscricao'),
    path('listacargos/',views.cargos, name='listacargos'), 
    path('frmcargo/',views.frmcargo, name='frmcargo'), 
    path('jwcapp/',views.jwcapp, name='jwcapp'),
]
