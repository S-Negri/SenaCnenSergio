from django.apps import AppConfig


class JwcappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'JWCapp'
